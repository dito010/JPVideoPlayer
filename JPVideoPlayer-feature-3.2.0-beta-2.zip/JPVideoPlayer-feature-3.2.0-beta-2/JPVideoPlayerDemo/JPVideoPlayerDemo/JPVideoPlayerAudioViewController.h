//
//  JPVideoPlayerAudioViewController.h
//  JPVideoPlayerDemo
//
//  Created by NewPan on 2018/5/25.
//  Copyright © 2018年 NewPan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JPVideoPlayerAudioViewController : UIViewController

@end
