//
//  JPVideoPlayerCollectionViewController.h
//  ComponentDemo
//
//  Created by Xuzixiang on 2018/6/4.
//  Copyright © 2018年 frankxzx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JPVideoPlayerCollectionViewController : UIViewController

@end
